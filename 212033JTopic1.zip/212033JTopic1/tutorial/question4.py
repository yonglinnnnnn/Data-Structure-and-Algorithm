# question 4a
list = []
for i in range(50, 90, 10):
    list.append(i)
print(list)

print()

#question 4b
list2 = []
for k in range(8, -9, -2):
    list2.append(k)
print(list2)